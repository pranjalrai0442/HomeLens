package com.pranjal.HomLens.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pranjal.HomLens.model.PropertyDetails;

@Repository
public interface HomelensPropertyRepo extends JpaRepository<PropertyDetails, Long>{

	List<PropertyDetails> findByCity(String city);

	List<PropertyDetails> findByPostedBy(String username);

	List<PropertyDetails> findByCityAndPriceLessThanEqualAndType(String city, long price, String type);

	@Query("SELECT DISTINCT p FROM PropertyDetails p LEFT JOIN FETCH p.images WHERE p.postedBy = :username")
	List<PropertyDetails> findByPostedByWithImages(@Param("username") String username);
	
}
