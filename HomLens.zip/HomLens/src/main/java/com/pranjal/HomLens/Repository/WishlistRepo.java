package com.pranjal.HomLens.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pranjal.HomLens.model.Wishlist;

@Repository
public interface WishlistRepo extends JpaRepository<Wishlist, Long>{


	List<Wishlist> findByUserid(long userid);

	Optional<Wishlist> findByUseridAndPropertyId(long userid, long propid);

	void deleteByPropertyId(Long id);

	void deleteByUseridAndPropertyId(long userid, Long propid);

	
}
