package com.pranjal.HomLens.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pranjal.HomLens.Repository.PropertyImageRepository;
import com.pranjal.HomLens.Repository.UserdetailsRepo;
import com.pranjal.HomLens.model.PropertyDetails;
import com.pranjal.HomLens.model.PropertyImage;
import com.pranjal.HomLens.model.Userdetails;
import com.pranjal.HomLens.service.HomelensService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
public class HomelensController {

	@Autowired
	HomelensService serv;
	
	@Autowired
	UserdetailsRepo userRepo;
	
	@Autowired
	PropertyImageRepository imgRepository;
	
	
	
	@GetMapping("/me")
	public ResponseEntity<Map<String, Object>> getUser(@AuthenticationPrincipal OAuth2User oauthUser) {

	    if (oauthUser == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
	    }

	    String email = oauthUser.getAttribute("email");

	    Userdetails user = userRepo.findByEmail(email);

	    Map<String, Object> response = new HashMap<>();

	    if (user == null) {
	        response.put("newUser", true);
	        response.put("email", email);
	    } else {
	        response.put("name", user.getName());
	        response.put("email", user.getEmail());
	        response.put("role", user.getRole());
	    }

	    return ResponseEntity.ok(response);
	}
	
	@GetMapping("/login")
	public void handleLoginError(HttpServletRequest request, HttpServletResponse response) throws IOException {

	    String error = request.getParameter("error");

	    if (error != null) {	        
	        request.getSession().invalidate();

	        response.sendRedirect("http://localhost:5173/");
	    }
	}

	@GetMapping("/userstatus")
	public ResponseEntity<String> checkUser(@AuthenticationPrincipal OAuth2User oauthUser) {

		String email = oauthUser.getAttribute("email");

		return serv.checkuser(email);

	}

	@GetMapping("/currentuser")
	public OAuth2User currentUser(@AuthenticationPrincipal OAuth2User user) {
		return user;
	}

	@GetMapping("/currentuserdetails")
	public ResponseEntity<Userdetails> currentUserdetails(@AuthenticationPrincipal OAuth2User user) {
		return serv.getcurrentuser(user);
	}

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestParam String name, @RequestParam String role,
			@AuthenticationPrincipal OAuth2User oauthUser) {

		return serv.saveuser(name, role, oauthUser);
	}

	@PostMapping(value = "/addproperty", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<String> saveProperty(@RequestParam String description, @RequestParam String address,
			@RequestParam long price, @RequestParam String area, @RequestParam long pincode, @RequestParam String city,
			@RequestParam String type, @RequestParam long contactnumber,
			@RequestParam("images") List<MultipartFile> images, @AuthenticationPrincipal OAuth2User oauthUser

	) throws IOException {

		serv.addproperty(description, address, price, area, pincode, city, type, contactnumber, images, oauthUser);
		System.out.println("Images received: " + images.size());
		return new ResponseEntity<>("Property saved successfully", HttpStatus.OK);
	}

	@GetMapping("/searchproperty")
	public ResponseEntity<List<PropertyDetails>> getproperties(@RequestParam String city,@RequestParam long price,@RequestParam String type) {

		return serv.getproperty(city,price,type);

	}

	@GetMapping("/propertyimage/{id}")
	public ResponseEntity<byte[]> getImage(@PathVariable Long id) {

	    PropertyImage image = imgRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Image not found"));

	    return ResponseEntity.ok()
	            .contentType(MediaType.valueOf(image.getImageType()))
	            .body(image.getImageData());
	}

	@GetMapping("/viewpostedproperties")
	public ResponseEntity<List<PropertyDetails>> getpostedjobs(@AuthenticationPrincipal OAuth2User oAuth2User) {
		
		return serv.getpostedJobs(oAuth2User);

	}

	@GetMapping("/wishlist")
	public ResponseEntity<List<PropertyDetails>> getwishlist(@AuthenticationPrincipal OAuth2User oAuth2User) {

		return serv.getwishlist(oAuth2User);

	}

	
	  @GetMapping("/viewproperty/{id}")
	  public PropertyDetails getproperties(@PathVariable long id){
	  
		  System.out.println("viewed");
		  
	  return serv.getproperty(id);
	 
	  }
	 

	  @PostMapping("/addtowishlist/{propid}")
	  public String addwishlist(@PathVariable long propid,@AuthenticationPrincipal OAuth2User oauth) {
		
		  
		  
		  return serv.addwishlist(propid,oauth);
		  
		  
	  }
	  
	  
	  @PostMapping("/updateproperty/{id}")
	  public void updateProperty(
	          @PathVariable Long id,
	          @RequestParam("description") String description,
	          @RequestParam("address") String address,
	          @RequestParam("price") long price,
	          @RequestParam("area") String area,
	          @RequestParam("pincode") long pincode,
	          @RequestParam("city") String city,
	          @RequestParam("type") String type,
	          @RequestParam("contactnumber") long contactnumber,
	          @AuthenticationPrincipal OAuth2User oauthUser,
	          HttpServletResponse response
	  ) throws IOException {

	      serv.updateProperty(id, description, address, price, area,
	              pincode, city, type, contactnumber, oauthUser);

	      response.sendRedirect("http://localhost:5173/my-properties?msg=updated");
	  }
	  
	  @PostMapping("/removefromwishlist/{propid}")
	  public ResponseEntity<String> removeFromWishlist(
	          @PathVariable long propid,
	          @AuthenticationPrincipal OAuth2User oauthUser) {

	      return serv.removeFromWishlist(propid, oauthUser);
	  }
	  
	  @PostMapping("/deleteproperty/{id}")
	  public ResponseEntity<String> deleteProperty(
	          @PathVariable Long id,
	          @AuthenticationPrincipal OAuth2User oauthUser) {

	      return serv.deleteProperty(id, oauthUser);
	  }
	  
	  
	  
	  
	  
	  
	  
	  
}
