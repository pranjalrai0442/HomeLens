package com.pranjal.HomLens.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.pranjal.HomLens.Repository.HomelensPropertyRepo;
import com.pranjal.HomLens.Repository.PropertyImageRepository;
import com.pranjal.HomLens.Repository.UserdetailsRepo;
import com.pranjal.HomLens.Repository.WishlistRepo;
import com.pranjal.HomLens.model.PropertyDetails;
import com.pranjal.HomLens.model.PropertyImage;
import com.pranjal.HomLens.model.Userdetails;
import com.pranjal.HomLens.model.Wishlist;

@Service
public class HomelensService {

	@Autowired
	HomelensPropertyRepo propertyRepo;
	
	@Autowired
	PropertyImageRepository imageRepository;
	
	@Autowired
	UserdetailsRepo userrepo;
	
	@Autowired
	WishlistRepo wishrepo;
	
	
	@Transactional
	public ResponseEntity<String> addproperty(
	        String description,
	        String address,
	        long price,
	        String area,
	        long pincode,
	        String city,
	        String type,
	        long contactnumber,
	        List<MultipartFile> images,
	        OAuth2User oauthUser) throws IOException {

	    String username = oauthUser.getAttribute("email");
	    Userdetails user = userrepo.findByEmail(username);

	    if (user == null || !user.getRole().equals("BROKER")) {
	        return new ResponseEntity<>("Unauthorized Access", HttpStatus.UNAUTHORIZED);
	    }
	    
	    PropertyDetails property = new PropertyDetails();
	    property.setBrokerid(user.getUserid());
	    property.setDescription(description);
	    property.setAddress(address);
	    property.setPrice(price);
	    property.setArea(area);
	    property.setPincode(pincode);
	    property.setCity(city);
	    property.setType(type);
	    property.setContactnumber(contactnumber);
	    property.setPostedBy(username);

	    PropertyDetails savedProperty = propertyRepo.save(property);

	    List<PropertyImage> imageList = new ArrayList<>();

	    if (images != null && !images.isEmpty()) {
	        for (MultipartFile file : images) {

	            PropertyImage img = new PropertyImage();
	            img.setImageData(file.getBytes());
	            img.setImagename(file.getOriginalFilename());
	            img.setImageType(file.getContentType());
	            img.setPropertyId(savedProperty);

	            imageList.add(img);
	        }

	        imageRepository.saveAll(imageList);
	    }

	    savedProperty.setImages(imageList);

	    propertyRepo.save(savedProperty);

	    return new ResponseEntity<>("Property Added Successfully", HttpStatus.OK);
	}



	
	@Transactional
	public ResponseEntity<List<PropertyDetails>> getpostedJobs(OAuth2User oauthUser) {

	    String username = oauthUser.getAttribute("email");
	    Userdetails user = userrepo.findByEmail(username);

	    if (!user.getRole().equals("BROKER")) {
	        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
	    }

	    List<PropertyDetails> properties =propertyRepo.findByPostedByWithImages(username);
	    
	    for (PropertyDetails p : properties) {
	        System.out.println("Property ID: " + p.getPropertyid());
	        System.out.println("Images: " + p.getImages());
	    }
	    
	    return new ResponseEntity<>(properties, HttpStatus.OK);
	}





	public String saveuser(Userdetails userdetails) {
		
		
		if (userrepo.existsByEmail(userdetails.getEmail())) {
		    return "Email already registered";
		}
		else {
			userrepo.save(userdetails);
			return "Registered";
		}
	}





	public ResponseEntity<List<PropertyDetails>> getwishlist(OAuth2User oauthUser) {
		
		String username = oauthUser.getAttribute("email");
		Userdetails user =  userrepo.findByEmail(username);
		long userid=user.getUserid();
		
		List<Wishlist> templist= wishrepo.findByUserid(userid);
		
		List<PropertyDetails> wishlist = new ArrayList<>();
		
		for(Wishlist wish:templist) {
			
			PropertyDetails prop=propertyRepo.findById(wish.getPropertyId())
								 .orElseThrow(()-> new RuntimeException("Object not found"));
			wishlist.add(prop);
			
		}
		
		return new ResponseEntity<List<PropertyDetails>>(wishlist,HttpStatus.OK);
	}





	public PropertyDetails getproperty(long id) {
		PropertyDetails prop = propertyRepo.findById(id).orElseThrow(()->new RuntimeException("Property Not found"));
		return prop;
	}





	public String updateProperty(long id, String description, String address, long price, String area, long pincode,
			String city, String type, long contactnumber, OAuth2User oauthUser) {
		
		PropertyDetails prop = propertyRepo.findById(id).orElseThrow(()->new RuntimeException("No property found"));
		
		String username=oauthUser.getAttribute("email");
		
		
		if (!prop.getPostedBy().equals(username)) {
		    throw new RuntimeException("Not authorised");
		}
		
		    prop.setDescription(description);
		    prop.setAddress(address);
		    prop.setPrice(price);
		    prop.setArea(area);
		    prop.setPincode(pincode);
		    prop.setCity(city);
		    prop.setType(type);
		    prop.setContactnumber(contactnumber);

		    propertyRepo.save(prop);

		    return "Property updated successfully";

	}




	public ResponseEntity<String> saveuser(String name, String role, OAuth2User oauthUser) {
		
		if (userrepo.existsByEmail(oauthUser.getAttribute("email"))){
		    return new ResponseEntity<String>("Email already registered",HttpStatus.OK);
		}
		else {
			Userdetails user = new Userdetails();
			user.setEmail(oauthUser.getAttribute("email"));
			user.setName(name);
			user.setRole(role);
			userrepo.save(user);
			return new ResponseEntity<String>("Registered",HttpStatus.OK);
			
		}
		
	}




	public ResponseEntity<String> checkuser(String email) {
		if(userrepo.existsByEmail(email)) {
			
			return ResponseEntity.ok("EXISTS");
	    }

	    return ResponseEntity.ok("NEW");
	}




	public ResponseEntity<Userdetails> getcurrentuser(OAuth2User user) {
		if(userrepo.existsByEmail(user.getAttribute("email"))) {
			Userdetails currentuser = userrepo.findByEmail(user.getAttribute("email"));
	        return new ResponseEntity<>(currentuser,HttpStatus.OK);
	    }

		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}




	public ResponseEntity<byte[]> getimages(long imageId) {

		PropertyImage image = imageRepository.findById(imageId).orElse(null);

	    if(image == null){
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }

	    return ResponseEntity
	            .ok()
	            .contentType(MediaType.valueOf(image.getImageType()))
	            .body(image.getImageData());
		}




	@Transactional
	public ResponseEntity<List<PropertyDetails>> getproperty(String city, long price, String type) {
		
		List<PropertyDetails> properties=propertyRepo.findByCity(city);
		List<PropertyDetails> responseProperty=new ArrayList<>();
		
		for(PropertyDetails prop:properties) {
			
			if((prop.getPrice()<=price) && (prop.getType().equals(type))) {
				responseProperty.add(prop);
			}
			
		}
		
		System.out.println(responseProperty);
		
		return new ResponseEntity<List<PropertyDetails>>(responseProperty,HttpStatus.OK);
	}




	public String addwishlist(long propid, OAuth2User oauth) {

	    String username = oauth.getAttribute("email");
	    Userdetails user = userrepo.findByEmail(username);

	    long userid = user.getUserid();

	    Optional<Wishlist> existing =
	        wishrepo.findByUseridAndPropertyId(userid, propid);

	    if (existing.isPresent()) {
	        return "Already in wishlist";
	    }

	    Wishlist wish = new Wishlist();
	    wish.setPropertyId(propid);
	    wish.setUserid(userid);

	    wishrepo.save(wish);

	    return "Added to wishlist";
	}
	
	

	@Transactional
	public ResponseEntity<String> removeFromWishlist(Long propid, OAuth2User oauthUser) {

	    String email = oauthUser.getAttribute("email");

	    Userdetails user = userrepo.findByEmail(email);

	    wishrepo.deleteByUseridAndPropertyId(user.getUserid(), propid);

	    return new ResponseEntity<>("Removed from wishlist", HttpStatus.OK);
	}

	
	@Transactional
	public ResponseEntity<String> deleteProperty(Long id, OAuth2User oauthUser) {

	    String email = oauthUser.getAttribute("email");
	    PropertyDetails property = propertyRepo.findById(id).orElse(null);

	    if (property == null) {
	        return new ResponseEntity<>("Property not found", HttpStatus.NOT_FOUND);
	    }

	    if (!property.getPostedBy().equals(email)) {
	        return new ResponseEntity<>("Unauthorized", HttpStatus.FORBIDDEN);
	    }
	    
	    wishrepo.deleteByPropertyId(id);

	    propertyRepo.delete(property);

	    return new ResponseEntity<>("Property deleted successfully", HttpStatus.OK);
	}




	public ResponseEntity<Map<String, Object>> findByEmail(String email) {

	    Userdetails user = userrepo.findByEmail(email);

	    Map<String, Object> response = new HashMap<>();

	    if (user == null) {
	        response.put("email", email);
	        response.put("newUser", true);
	        return ResponseEntity.ok(response);
	    }

	    response.put("name", user.getName());
	    response.put("email", user.getEmail());
	    response.put("role", user.getRole());
	    response.put("newUser", false);

	    return ResponseEntity.ok(response);
	}
	 
	
	
	
}
