package com.pranjal.HomLens;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;

import com.pranjal.HomLens.Repository.UserdetailsRepo;
import com.pranjal.HomLens.model.Userdetails;

@Configuration
public class SpringConfig {

    @Autowired
    private UserdetailsRepo userRepo;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                        "/",
                        "/error",
                        "/oauth2/**",
                        "/me",
                        "/register",
                        "/currentuserdetails",
                        "/signup"
                ).permitAll()
                .anyRequest().authenticated()
            )

            .oauth2Login(oauth -> oauth
                .failureHandler((request, response, exception) -> {
                    request.getSession().invalidate();
                    response.sendRedirect("http://localhost:5173/");
                })

                .successHandler((request, response, authentication) -> {

                    OAuth2User user = (OAuth2User) authentication.getPrincipal();
                    String email = user.getAttribute("email");

                    Userdetails dbUser = userRepo.findByEmail(email);

                    if (dbUser == null) {
                        response.sendRedirect("http://localhost:5173/signup");
                    } else {
                        if ("BROKER".equals(dbUser.getRole())) {
                            response.sendRedirect("http://localhost:5173/seller-home");
                        } else {
                            response.sendRedirect("http://localhost:5173/buyer-home");
                        }
                    }
                })
            )

            .sessionManagement(session -> session
                .sessionFixation().migrateSession()
                .maximumSessions(1)
                .maxSessionsPreventsLogin(false)
            )

            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("http://localhost:5173/")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .clearAuthentication(true)
            );

        return http.build();
    }
}