package com.pranjal.HomLens.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pranjal.HomLens.model.Userdetails;

@Repository
public interface UserdetailsRepo extends JpaRepository<Userdetails, Long>{

	Userdetails findByEmail(String username);

	boolean existsByEmail(String email);

}
