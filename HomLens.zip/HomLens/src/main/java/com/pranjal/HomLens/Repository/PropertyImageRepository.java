package com.pranjal.HomLens.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pranjal.HomLens.model.PropertyImage;


@Repository
public interface PropertyImageRepository extends JpaRepository<PropertyImage,Long>{

	
	
}
