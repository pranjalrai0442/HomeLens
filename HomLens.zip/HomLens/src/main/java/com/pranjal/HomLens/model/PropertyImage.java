package com.pranjal.HomLens.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;

@Entity
public class PropertyImage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long imageid;
	private String imagename;
	private String imageType;
	
	@ManyToOne
	@JsonBackReference 
	@JoinColumn(name = "propertyid")
	private PropertyDetails propertyId;
	

	public PropertyDetails getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(PropertyDetails propertyId) {
		this.propertyId = propertyId;
	}

	public String getImagename() {
		return imagename;
	}

	public void setImagename(String imagename) {
		this.imagename = imagename;
	}

	public String getImageType() {
		return imageType;
	}

	public void setImageType(String imageType) {
		this.imageType = imageType;
	}

	public byte[] getImageData() {
		return imageData;
	}

	public void setImageData(byte[] imageData) {
		this.imageData = imageData;
	}

	@Lob
	@JsonIgnore
	private byte[] imageData;


	public long getImageid() {
		return imageid;
	}

	public void setImageid(long imageid) {
		this.imageid = imageid;
	}
	
	
}
