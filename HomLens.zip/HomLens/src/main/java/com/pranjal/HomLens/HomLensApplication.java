package com.pranjal.HomLens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomLensApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomLensApplication.class, args);
		System.out.println("Jai Shree Ganesh");
	}

}
